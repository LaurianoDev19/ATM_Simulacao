package com.bejj.api.Infra.Seguranca;

import com.bejj.api.adm.AdmRepository;
import com.bejj.api.adm.AdmService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class FiltroSeguranca extends OncePerRequestFilter {
    @Autowired
    private TokenService tokenService;

    @Autowired
    private AdmService admService;

    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // 1. Pega o token do cabeçalho da requisição (Header "Authorization")
        String tokenJWT = recuperarToken(request);

        if (tokenJWT != null) {
            // 2. Valida o token e descobre de quem é o e-mail (Subject)
            String email = tokenService.getSubject(tokenJWT);
            
            // 3. Procura o Admin no banco de dados
            var adm = admService.buscarAdmEmail(email);

            // 4. Dizer ao Spring Security: "Esta requisição é do Admin X, pode liberar!"
            var autencacao = new UsernamePasswordAuthenticationToken(adm, null, adm.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(autencacao);
        }

        // 5. Continua o fluxo normal da requisição
        filterChain.doFilter(request, response);
    }

    private String recuperarToken(HttpServletRequest request) {
        String authorizationHeader = request.getHeader("Authorization");
        if (authorizationHeader != null) {
            return authorizationHeader.replace("Bearer ", "");
        }
        return null;
    }
}
