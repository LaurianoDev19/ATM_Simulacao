package com.bejj.api.adm;
import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
public class Senha {


    private static final int ITERATIONS = 2;       // Custo de tempo (iterações)
    private static final int MEMORY_KB = 32768;    // Custo de memória (64 MB)
    private static final int PARALLELISM = 1;       // Custo de paralelismo (número de threads)


    /**
     * Gera o hash da senha usando o algoritmo Argon2id.
     * 
     * @param senhaTextoPlano A senha digitada pelo utilizador em texto puro.
     * @return O hash seguro contendo a configuração, o salt e a saída final.
     */
    public static String criarHash(char[] senhaTextoPlano) {
        // Instancia o Argon2 no modo Argon2id
        Argon2 argon2 = Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);

        try {
            // Gera o hash automaticamente com salt seguro e aleatório
            return argon2.hash(ITERATIONS, MEMORY_KB, PARALLELISM, senhaTextoPlano);
        } finally {
            // É uma boa prática wipe (limpar) a senha da memória
            argon2.wipeArray(senhaTextoPlano);
        }
    }


    /**     
     * @param hashSalvo O hash gerado anteriormente e salvo na base de dados.
     * @param senhaCandidata A senha inserida para autenticação.
     * @return true se a senha for válida, false caso contrário.
     */
    public static boolean verificar(String hashSalvo, char[] senhaCandidata) {
        Argon2 argon2 = Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);

        try {
            // O método verify extrai os parâmetros e o salt diretamente da String do hash
            return argon2.verify(hashSalvo, senhaCandidata);
        } finally {
            argon2.wipeArray(senhaCandidata);
        }
    }
}
