package com.bejj.api;

public class RecursoNaoEncontrado extends RuntimeException{

    public RecursoNaoEncontrado(String mensagem){

        super(mensagem);
    }
}
