package com.bejj.api.Imagem;

public record BuscarImagens(

    String url

) {
    public BuscarImagens(Galeria galeria){
        this(galeria.getUrl());
    }
}
