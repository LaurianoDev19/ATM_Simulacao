package com.bejj.api.post;
import java.util.List;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;



@Service
@RequiredArgsConstructor
public class PostService {

    private final PostRepository respositorio;

    public void salvar(List<PostCadastro> lista){
        respositorio.saveAll(lista.stream().map(Post::new).toList());
    }

    public void excluirPost(Long id){
        respositorio.deletarPorId(id);
    }
}
