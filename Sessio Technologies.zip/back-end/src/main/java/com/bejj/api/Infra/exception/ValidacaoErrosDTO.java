package com.bejj.api.Infra.exception;

import org.springframework.validation.FieldError;
public record ValidacaoErrosDTO(String campo, String mensagem) {
    public ValidacaoErrosDTO(FieldError erro){
        this(erro.getField(), erro.getDefaultMessage());
    }
}
