package com.bejj.api.post;

import java.time.LocalDate;
import jakarta.validation.constraints.NotBlank;
// import jakarta.validation.constraints.NotNull;

public record PostCadastro(

    @NotBlank
    String titulo,

    @NotBlank
    String corpo_Post,

    LocalDate data_Publicacao,

    String url_Imagem
) {
    
}
