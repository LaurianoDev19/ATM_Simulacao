package com.bejj.api.Imagem;


import jakarta.persistence.*;
import lombok.*;

@Entity(name = "Galeria")
@Table(name = "galeria")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Galeria{

    public Galeria(CadastrarImagem cadastrarImagem) {
        this.url = cadastrarImagem.url();
        this.categoria = cadastrarImagem.categoria();
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String url;

    @Enumerated(EnumType.STRING)
    private Categoria categoria;
}