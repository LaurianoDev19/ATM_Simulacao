package com.bejj.api.adm;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
public interface AdmRepository extends JpaRepository<Adm, Integer> {
    
    Optional<Adm> findByEmail(String email);
    
}
