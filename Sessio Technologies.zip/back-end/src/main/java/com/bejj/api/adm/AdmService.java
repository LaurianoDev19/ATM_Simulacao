package com.bejj.api.adm;

import org.springframework.stereotype.Service;

import com.bejj.api.RecursoNaoEncontrado;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdmService {

    private final AdmRepository repository;

    public void cadastrar(AdmCadastrar dados){
        Adm adm = new Adm(dados);
        repository.save(adm);
    }

    public BuscarAdm buscarPorEmail(String email){
        Adm adm = repository.findByEmail(email)
        .orElseThrow( () -> new RecursoNaoEncontrado("Adm nao encontrdo: "+email));

        return new BuscarAdm(adm);
    }

    public Adm buscarAdmEmail(String email){
        return repository.findByEmail(email)
        .orElseThrow( () -> new RecursoNaoEncontrado("Adm nao encontrdo: "+email));
    }

}
