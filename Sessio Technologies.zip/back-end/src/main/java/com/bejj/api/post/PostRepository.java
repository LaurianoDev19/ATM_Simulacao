package com.bejj.api.post;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostRepository extends JpaRepository<Post, Long> {
    
    void deletarPorId(Long id);
}
