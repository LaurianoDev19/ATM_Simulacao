package com.bejj.api.Imagem;

import jakarta.validation.constraints.*;

public record CadastrarImagem(

    @NotBlank(message = "O campo url é obrigatório")
    String url,

    @NotNull(message = "O campo titulo é obrigatório")
    Categoria categoria

) {
    
    
}
