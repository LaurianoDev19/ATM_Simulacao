package com.bejj.api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
@RequestMapping("/bora")
public class BoraProduzir {
    
    @GetMapping
    public String boraProduzir() {
        return String.format("Bora Produzir!%nAqui e o ponto de partida da nossa jornada.%nBoa sorte a todos, vamos Sessio Technologies");
    }
}
