package com.bejj.api.post;

import java.time.LocalDate;

public record ListarPostagem(
    
    Long id,

    String titulo,

    String corpo_Post,

    String url_Imagem,

    LocalDate data_Publicacao

) {
    public ListarPostagem(Post postagem){
        this(
            postagem.getId(),
            postagem.getTitulo(),
            postagem.getCorpo_Post(),
            postagem.getUrl_Imagem(),
            postagem.getData_Publicacao()
        );
    }
}
