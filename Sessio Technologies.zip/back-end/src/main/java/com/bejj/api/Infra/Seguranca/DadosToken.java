package com.bejj.api.Infra.Seguranca;

public record DadosToken(

    String token,

    String tipo

) {
    
}
