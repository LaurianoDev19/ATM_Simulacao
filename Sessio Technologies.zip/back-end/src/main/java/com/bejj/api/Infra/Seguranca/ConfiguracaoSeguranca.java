package com.bejj.api.Infra.Seguranca;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import java.util.List;

@Configuration
@EnableWebSecurity
public class ConfiguracaoSeguranca {

    @Autowired
    private FiltroSeguranca securityFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource())) // <-- HABILITA O CORS AQUI
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(req -> {
                    // Permite chamadas OPTIONS automáticas de preflight do navegador para qualquer
                    // rota
                    req.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll();

                    // Visitantes podem ver posts e galeria, e usar o endpoint de login
                    req.requestMatchers(HttpMethod.GET, "/post/**").permitAll();
                    req.requestMatchers(HttpMethod.GET, "/imagem/**").permitAll();
                    req.requestMatchers(HttpMethod.POST, "/login").permitAll();
                    req.requestMatchers(HttpMethod.GET, "/bora").permitAll();
                    req.requestMatchers(HttpMethod.POST, "/adm/**").permitAll();
                    req.requestMatchers(HttpMethod.GET, "/adm/**").permitAll();

                    // Para criar, editar ou apagar, exige Token JWT
                    req.anyRequest().authenticated();
                })
                // Registra o nosso filtro para rodar antes da verificação padrão
                .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // Instancia o encoder com as configurações padrão recomendadas do Argon2
        return Argon2PasswordEncoder.defaultsForSpringSecurity_v5_8();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();

        // 1. Origens permitidas (Substitui pelas URLs reais do teu front-end em
        // produção/dev)
        configuration.setAllowedOrigins(List.of(
                "http://localhost:3000", // React / Next.js
                "http://localhost:5173", // Vite / Vue
                "http://127.0.0.1:5500" // Live Server do VS Code
        ));

        configuration.setAllowedOriginPatterns(List.of(
                "http://localhost:[*]",
                "http://127.0.0.1:[*]",
                "https://*.trycloudflare.com" // Permite qualquer link temporário gerado
        ));

        // 2. Métodos HTTP permitidos
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));

        // 3. Cabeçalhos permitidos (necessário para enviar o Authorization com o JWT)
        configuration.setAllowedHeaders(List.of("Authorization", "Content-Type", "Cache-Control"));

        // 4. Permitir envio de credenciais (cookies, headers de autenticação)
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration); // Aplica a todas as rotas da API
        return source;
    }

    
}
