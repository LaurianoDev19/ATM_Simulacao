package com.bejj.api.post;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.bejj.api.adm.Adm;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity(name = "Post")
@Table(name = "post")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Post {

    public Post(PostCadastro post){
        this.titulo=post.titulo();
        this.corpo_Post= post.corpo_Post();
        this.data_Publicacao=post.data_Publicacao();
        this.url_Imagem=post.url_Imagem();
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String titulo;
    String corpo_Post;
    String url_Imagem;
    LocalDate data_Publicacao;


}
