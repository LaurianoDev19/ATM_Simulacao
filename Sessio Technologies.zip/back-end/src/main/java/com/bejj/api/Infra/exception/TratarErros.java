package com.bejj.api.Infra.exception;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;
import java.util.Map;

@RestControllerAdvice
public class TratarErros {

    // 1. Trata erros 404 (Entidade/Registro não encontrado)
    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<Void> tratarErro404() {
        return ResponseEntity.notFound().build();
    }

    // 2. Trata erros 400 de validação do Beans Validation (@Valid / @NotBlank /
    // @Email etc)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<List<ValidacaoErrosDTO>> tratarErro400(MethodArgumentNotValidException ex) {
        List<FieldError> erros = ex.getFieldErrors();
        return ResponseEntity.badRequest().body(erros.stream().map(ValidacaoErrosDTO::new).toList());
    }

    // 3. Trata erros de duplicidade de chaves (ex: e-mail único duplicado no banco)
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, String>> tratarErroDuplicidade(DataIntegrityViolationException ex){
        Map<String, String> resposta = Map.of(
            "erro", "Conflito de dados",
            "mensagem", "Já existe um registro com estes dados cadastrados.");
        return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
    }

    // 4. Trata exceções genéricas inesperadas (500 Internal Server Error)
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> tratarErro500(Exception ex) {
        Map<String, String> resposta = Map.of(
                "erro", "Erro interno no servidor",
                "mensagem", ex.getLocalizedMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resposta);
    }
}
