package com.bejj.api.controller;

import com.bejj.api.post.ListarPostagem;
import com.bejj.api.post.Post;
import com.bejj.api.post.PostCadastro;
import com.bejj.api.post.PostRepository;
import com.bejj.api.post.PostService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/post")
@CrossOrigin(origins = "*")
public class PostController {

    @Autowired
    PostService service;

    @Autowired
    PostRepository repository;

    @PostMapping
    @Transactional
    public void cadstrarPost(@RequestBody @Valid List<PostCadastro> postagem) {
        service.salvar(postagem);
    }
    /* 
    @GetMapping
    @Transactional
    public List<ListarPostagem> listarPost() {
        return repository.findAll().stream()
                .map(ListarPostagem::new).toList();

    }
    */

    
    @GetMapping
    public ResponseEntity<Page<ListarPostagem>> listar(
            @PageableDefault(size = 10, sort = { "id" }, direction = Sort.Direction.DESC) Pageable paginacao) {

        // O método findAll(paginacao) do Spring Data JPA traz apenas os registros da
        // página solicitada
        var pagina = repository.findAll(paginacao).map(ListarPostagem::new);

        return ResponseEntity.ok(pagina);
    }

    @DeleteMapping("/{id}")
    @Transactional
    public void excluirPost(@PathVariable Long id){
        service.excluirPost(id);
    }
    
}
