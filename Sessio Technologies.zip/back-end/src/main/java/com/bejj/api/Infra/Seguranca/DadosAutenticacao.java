package com.bejj.api.Infra.Seguranca;

import jakarta.validation.constraints.NotBlank;

public record DadosAutenticacao(
    @NotBlank
    String email,

    @NotBlank
    String senha
) {
    
}
