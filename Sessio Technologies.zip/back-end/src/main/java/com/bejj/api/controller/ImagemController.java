package com.bejj.api.controller;
import org.springframework.web.bind.annotation.*;
import com.bejj.api.Imagem.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import java.util.List;
@RestController
@RequestMapping("/imagem")
public class ImagemController {

    @Autowired
    ImagemService imagemService;


    @PostMapping
    @Transactional
    public void salvarNaGaleria(@RequestBody List<CadastrarImagem> cadastrarImagem){
        imagemService.salvar(cadastrarImagem);

    }

    @GetMapping("/{categoria}")
    public List<BuscarImagens> listarPorCategoria(@PathVariable Categoria categoria){

       return imagemService.listarPorCategoria(categoria);
    }

}
