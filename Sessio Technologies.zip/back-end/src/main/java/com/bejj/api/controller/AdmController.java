package com.bejj.api.controller;
import com.bejj.api.adm.AdmCadastrar;
import com.bejj.api.adm.AdmRepository;
import com.bejj.api.adm.AdmService;
import com.bejj.api.adm.BuscarAdm;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.bejj.api.adm.Adm;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
@RestController
@RequestMapping("/adm")
@RequiredArgsConstructor
public class AdmController {

    @Autowired
    AdmRepository repository;
    private final AdmService service ;
    
    @PostMapping
    @Transactional
    public void cadastrarAdm(@RequestBody @Valid AdmCadastrar admCadastrar) {
        service.cadastrar(admCadastrar);
    }

    @GetMapping("/{id}")
    @Transactional
    public List<BuscarAdm> listarAdmPorId(@PathVariable int id){
       return  repository.findById(id)
       .stream()
       .map(BuscarAdm::new)
       .toList();
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<BuscarAdm> listarAdmPorEmail(@PathVariable String email){
        BuscarAdm lista = service.buscarPorEmail(email);
        return ResponseEntity.ok(lista);
    }
}
