package com.bejj.api.Imagem;

public enum Categoria{

    DEFESAPAP,
    PALESTRAS,
    BATISMOCALOUROS,
    JOGOSSOLIDARIO
}