package com.bejj.api.controller;


import jakarta.validation.Valid;
import com.bejj.api.Infra.Seguranca.DadosToken;
import com.bejj.api.adm.Adm;
import com.bejj.api.adm.AdmService;
import com.bejj.api.adm.Senha;
import com.bejj.api.Infra.Seguranca.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.bejj.api.Infra.Seguranca.DadosAutenticacao;
import com.bejj.api.adm.Login;

@RestController
@RequestMapping("/login")
public class AutenticacaoController {
    
    @Autowired
    private AdmService admService;

    @Autowired
    private TokenService tokenService;

    

    @PostMapping
    public ResponseEntity fazerLogin(@RequestBody @Valid DadosAutenticacao dados){
        
        Adm adm = admService.buscarAdmEmail(dados.email());
        char [] senhaAr = dados.senha().toCharArray();
        if(adm == null || !Senha.verificar(adm.getSenha(), senhaAr)){

            return ResponseEntity.status(401).body("E-mail ou senha inválidos!");
        }

        // 3. Se deu tudo certo, usa o TokenService para GERAR o token
        String tokenJWT = tokenService.gerarToken(adm);
        

        // 4. Devolve o token para o Front-end
        return ResponseEntity.ok(new DadosToken(tokenJWT, "Bearer"));
    }

}
