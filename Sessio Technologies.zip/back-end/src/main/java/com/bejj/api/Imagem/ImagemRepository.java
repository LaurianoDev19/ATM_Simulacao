package com.bejj.api.Imagem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ImagemRepository extends JpaRepository<Galeria, Long> {
    
    List<Galeria> findByCategoria(Categoria cat);
}
