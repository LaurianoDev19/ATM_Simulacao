package com.bejj.api.adm;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Collection;
import java.util.List;
import org.springframework.security.core.userdetails.UserDetails; // Import essencial
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;


@Table(name="adm")
@Entity(name="Adm")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Adm implements UserDetails{
    
    public Adm(AdmCadastrar admCadastrar) {
        this.nome = admCadastrar.nome();
        this.email = admCadastrar.email();
        this.senha = Senha.criarHash(admCadastrar.senha().toCharArray());
        this.telefone = admCadastrar.telefone();
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id_Adm;
    String nome;
    String email;
    String senha;
    String telefone;


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // Define o papel/perfil do usuário. Como é o administrador:
        return List.of(new SimpleGrantedAuthority("ROLE_ADMIN"));
    }

@Override
    public String getPassword() {
        return this.senha;
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
