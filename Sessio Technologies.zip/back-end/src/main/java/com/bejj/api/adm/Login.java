package com.bejj.api.adm;


import com.bejj.api.Infra.Seguranca.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import com.bejj.api.Infra.Seguranca.DadosAutenticacao;

public class Login {

    public Login(DadosAutenticacao dados){
        this.email=dados.email();
        this.senha=dados.senha().toCharArray();
    }

    String email;
    char[] senha;

    @Autowired
    private AdmService admService;

    @Autowired
    private TokenService tokenService = new TokenService();

    public String logar() {

        Adm adm = admService.buscarAdmEmail(this.email);
        //char[] senhaAr = this.senha;
        if (adm == null || !Senha.verificar(adm.getSenha(), this.senha)) {
            return "Email ou senha incorretas";
        }

        String tokenJWT = tokenService.gerarToken(adm);

        return tokenJWT;
    }
}
