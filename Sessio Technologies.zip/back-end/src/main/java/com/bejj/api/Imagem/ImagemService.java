package com.bejj.api.Imagem;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import com.bejj.api.RecursoNaoEncontrado;
import java.util.List;  

@Service
@RequiredArgsConstructor
public class ImagemService {
    
    private final ImagemRepository imgRepository;

    public void salvar(List<CadastrarImagem> img) {
        imgRepository.saveAll(img.stream().map(Galeria::new).toList());
    }

    public List<BuscarImagens> listarPorCategoria(Categoria cat) {
      
        List<Galeria> imagens = imgRepository.findByCategoria(cat);

        if(imagens.isEmpty()){
            //throw new RecursoNaoEncontrado("Nenhuma imagem desta categoria foi encontrada :"+cat);
        }

        return imagens.stream().map(BuscarImagens::new).toList();
    }
}
