package com.bejj.api.adm;

public record BuscarAdm(

    int id_Adm,
    
    String nome,

    String email,

    String senha,

    String telefone

) {

    public BuscarAdm(Adm admin){
        this(admin.getId_Adm(),
            admin.getNome(),
            admin.getEmail(),
            admin.getSenha(),
            admin.getTelefone()
        );
    }

}