package com.bejj.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstitutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
